import java.util.Scanner;
    public class Factorial {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите число: ");
        int n = scanner.nextInt();

        if (n < 0)
        {System.out.println("Нельзя вводить отрицательные числа!");}
        else if (n == 0) {}
        else {

            int fact1 = 1;
            for (int i = 1; i <= n; i++)
                fact1 = fact1 * i;

            int fact2 = 1;
            int i = 1;
            do {fact2*= i;
                i++;
            }while (i<=n);
            fact2 = fact2 * 1;
            System.out.println("Введите способ которым хотите решить 1 или 2: ");
            int choice = scanner.nextInt();
            if (choice== 1)System.out.println("Решение циклом for: " + fact1);
            else if (choice == 2)System.out.println("Решение циклом do while: "+ fact2);

            scanner.close();
        }
    }
}