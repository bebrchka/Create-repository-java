import org.jetbrains.annotations.Contract;

import java.util.Scanner;

public class calculator {
    private static double[] numbers;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Выберите действие:");
        System.out.println("1. Математические операции");
        System.out.println("2. Перевод между системами счисления");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                performCalculations(scanner);
                break;
            case 2:
                convertNumber(scanner);
                break;
            default:
                System.out.println("Неверный выбор. Попробуйте снова.");
        }
        scanner.close();
    }

    static void performCalculations(Scanner scanner) {
        System.out.println("Введите количество чисел (до 5):");
        int count = scanner.nextInt();
        if (count < 1 || count > 5) {
            System.out.println("Неверное количество чисел. Попробуйте снова.");
            return;
        }

        double[] numbers = new double[count];
        System.out.println("Введите " + count + " чисел:");
        for (int i = 0; i < count; i++) {
            numbers[i] = scanner.nextDouble();
        }

        System.out.println("Выберите операцию:");
        System.out.println("1. Сложение");
        System.out.println("2. Вычитание");
        System.out.println("3. Умножение");
        System.out.println("4. Деление");
        System.out.println("5. Деление с остатком");

        int operation = scanner.nextInt();
        switch (operation) {
            case 1:
                System.out.println("Результат сложения: " + add(numbers));
                break;
            case 2:
                System.out.println("Результат вычитания: " + subtract(numbers));
                break;
            case 3:
                System.out.println("Результат умножения: " + multiply(numbers));
                break;
            case 4:
                double result = divide(numbers);
                if (Double.isInfinite(result)) {
                    System.out.println("Ошибка: Деление на ноль!");
                } else {
                    System.out.println("Результат деления: " + result);
                }
                break;
            case 5:
                double result1 = Solution(numbers);
                if(Double.isInfinite(result1)){
                    System.out.println("Ошибка: Деление на ноль!");
                }else {
                    System.out.println("Результат деления с остатком: " +result1);
                }
            default:
                System.out.println("Неверная операция.");
        }
    }

    private static double add(double[] numbers) {
        double sum = 0;
        for (double num : numbers) {
            sum += num;
        }
        return sum;
    }
    private static double subtract(double[] numbers) {
        double result = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            result -= numbers[i];
        }
        return result;
    }
    private static double multiply(double[] numbers) {
        double product = 1;
        for (double num : numbers) {
            product *= num;
        }
        return product;
    }
    private static double divide(double[] numbers) {
        double result = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] == 0) {
                return Double.POSITIVE_INFINITY; // Возвращаем бесконечность в случае деления на 0
            } else {
                result /= numbers[i];
            }
        }
        return result;
    }
    private static double Solution(double[] numbers) {
        double result1 = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] == 0) {
                return Double.POSITIVE_INFINITY; // Возвращаем бесконечность в случае деления на 0
            } else {
                result1 %= numbers[i];
            }
        }
        return result1;
    }
    protected static void convertNumber(Scanner scanner) {
        System.out.println("Введите число:");
        int number = scanner.nextInt();
        System.out.println("10 в двоичной: " + Integer.toBinaryString(number));
        System.out.println("10 в восьмеричной: " + Integer.toOctalString(number));
        System.out.println("10 в шестнадцатеричной: " + Integer.toHexString(number).toUpperCase());
    }
}