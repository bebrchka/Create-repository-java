import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        int c;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое и второе число:");
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        System.out.println("1 - Сложение:" );
        System.out.println("2 - Умножение:");
        System.out.println("3 - Вычитание:");
        System.out.println("4 - Деление:");
        System.out.println("5 - Деление с остатком:");

        c = scanner.nextInt();
        switch (c) {
            case 1:
                System.out.println("1 - Сложение:" + a + b);
                break;
            case 2:
                System.out.println("2 - Умножение:" + (a * b));
                break;
            case 3:
                System.out.println("3 - Вычитание:" + (a - b));
                break;
            case 4:
                System.out.println("4 - Деление:"+ a / b);
                break;
            case 5:
                System.out.println("5 - Деление с остатком:" + a % b);
                break;
        }
    }
}