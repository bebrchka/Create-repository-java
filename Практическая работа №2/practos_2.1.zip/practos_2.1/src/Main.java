import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое и второе число:");
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        System.out.println("Выберите операцию:");
        System.out.println("1. Сложение:");
        System.out.println("2. Вычитание:");
        System.out.println("3. Умножение");
        System.out.println("4. Деление");
        System.out.println("5. деление с остатком: ");

        int choice = scanner.nextInt();
        if(choice == 1){System.out.println("1. Сложение: " +(a+b));
        }else if (choice == 2){System.out.println("2. Вычитание: " +(a-b));
        }else if (choice == 3){System.out.println("3. Умножение: " + (a*b));
        }else if (choice == 4){System.out.println("4. Деление:" + (a / b));
        }else if (choice == 5){System.out.println("5. деление с остатком: " +(a%b));}
        scanner.close();
    }
}

