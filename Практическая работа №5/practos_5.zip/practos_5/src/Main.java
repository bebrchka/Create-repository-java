import java.util.Scanner;
class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число: ");
        double n = scanner.nextInt();
        recurs(n);
    }
    private static double recurs(double n) {

        if (n > 0) {
            System.out.println(n + " ");
            recurs(n - 1);
        }
        return n;
    }
}