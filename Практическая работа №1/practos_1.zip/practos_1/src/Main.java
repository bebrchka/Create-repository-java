import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        // создаем объект Scanner для ввода данных
        Scanner scanner = new Scanner(System.in);

        // запрашиваем у пользователя ввод числа
        System.out.println("Введите число 1:");
        int i = scanner.nextInt();
        System.out.println("Введите число 2:");
        int a = scanner.nextInt();
        // ввыводим введеное число в консоль
        System.out.println("результат при сложении:"+i + a);
        System.out.println("результат при вычислении:" +(i- a));
        System.out.println("результат при умножении:"+i * a);
        System.out.println("результат при делении:"+i / a);
        System.out.println("результат при делении с остатком:"+i % a);
        System.out.println("результат при возведении в степень:"+Math.pow(i,a));
        System.out.println("результат при среднем арифметическом:"+(i + a)/2);
        // закрываем scanner
        scanner.close();
    }
}